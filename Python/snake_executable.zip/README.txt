The game can be found inside the dist folder


To run:
   
    -> On Windows:
        
        Double click the file

    -> On Linux/Mac:
    
        1. Open a terminal on the dist folder
       
        2. Write the following command:
            -----------------------
            | $ ./snake           |
            -----------------------
(In case the command does not work, erase the $ in the first character)
