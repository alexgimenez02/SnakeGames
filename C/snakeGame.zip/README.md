#How to play C Snake Game:

In case you do not find an executable inside the folder, follow the next instructions:

	1. Get gcc compiler (Windows, Linux or Mac)
	
	2. Execute `gcc snake.c -lncurses -o game (Linux & Mac)`
	   Execute `gcc snake.c -lncurses -o game.exe (Windows)`
	   
	3. (Linux & Mac): `./game`
	   (Windows): Double click on the game.exe icon
	   
	4. Enjoy!